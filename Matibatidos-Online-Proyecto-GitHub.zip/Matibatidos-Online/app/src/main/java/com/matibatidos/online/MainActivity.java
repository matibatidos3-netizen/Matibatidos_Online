package com.matibatidos.online;

import android.app.Activity;
import android.os.Bundle;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.webkit.JavascriptInterface;
import android.content.SharedPreferences;
import android.os.Handler;
import android.os.Looper;
import org.json.JSONObject;
import java.net.HttpURLConnection;
import java.net.URL;
import java.io.OutputStream;
import java.io.InputStream;
import java.io.ByteArrayOutputStream;
import java.nio.charset.StandardCharsets;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class MainActivity extends Activity {
    private WebView web;
    private final ExecutorService executor = Executors.newSingleThreadExecutor();
    private final Handler main = new Handler(Looper.getMainLooper());
    private SharedPreferences prefs;

    @Override public void onCreate(Bundle state) {
        super.onCreate(state);
        prefs = getSharedPreferences("matibatidos", MODE_PRIVATE);
        web = new WebView(this);
        web.getSettings().setJavaScriptEnabled(true);
        web.getSettings().setDomStorageEnabled(true);
        web.setWebViewClient(new WebViewClient());
        web.addJavascriptInterface(new Bridge(), "MatibatidosNative");
        setContentView(web);
        web.loadUrl("file:///android_asset/www/index.html");
    }

    public class Bridge {
        @JavascriptInterface public String getApiUrl() {
            return prefs.getString("apiUrl", "");
        }
        @JavascriptInterface public void setApiUrl(String url) {
            prefs.edit().putString("apiUrl", url == null ? "" : url.trim()).apply();
        }
        @JavascriptInterface public void request(String payload, String callback) {
            final String endpoint = prefs.getString("apiUrl", "");
            executor.execute(() -> {
                String result;
                try {
                    if (endpoint.isEmpty()) throw new Exception("Configura primero la URL de Apps Script.");
                    HttpURLConnection c = (HttpURLConnection)new URL(endpoint).openConnection();
                    c.setRequestMethod("POST");
                    c.setConnectTimeout(20000);
                    c.setReadTimeout(30000);
                    c.setDoOutput(true);
                    c.setRequestProperty("Content-Type", "application/json; charset=UTF-8");
                    try (OutputStream out = c.getOutputStream()) {
                        out.write(payload.getBytes(StandardCharsets.UTF_8));
                    }
                    InputStream in = (c.getResponseCode() >= 200 && c.getResponseCode() < 400)
                        ? c.getInputStream() : c.getErrorStream();
                    ByteArrayOutputStream buffer = new ByteArrayOutputStream();
                    byte[] data = new byte[4096]; int n;
                    while ((n = in.read(data)) != -1) buffer.write(data, 0, n);
                    in.close();
                    result = buffer.toString("UTF-8");
                } catch (Exception e) {
                    JSONObject err = new JSONObject();
                    try { err.put("ok", false); err.put("error", e.getMessage()); } catch(Exception ignored) {}
                    result = err.toString();
                }
                final String response = result;
                main.post(() -> web.evaluateJavascript(
                    "window.__nativeResponse(" + JSONObject.quote(callback) + "," +
                    JSONObject.quote(response) + ")", null));
            });
        }
    }

    @Override public void onBackPressed() {
        if (web != null && web.canGoBack()) web.goBack(); else super.onBackPressed();
    }
    @Override protected void onDestroy() {
        executor.shutdownNow();
        if (web != null) web.destroy();
        super.onDestroy();
    }
}
