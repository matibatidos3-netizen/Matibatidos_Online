const SHEETS = {
  Configuracion:["clave","valor"],
  Productos:["id","nombre","categoria","descripcion","precio","imagen","activo","permiteLeche"],
  Categorias:["id","nombre","orden","activo"],
  Pedidos:["id","codigo","fecha","cliente","telefono","tipoEntrega","direccion","notas","detalle","total","estado"],
  DetallePedidos:["pedidoId","productoId","nombre","cantidad","precio","leche","azucar","nota","subtotal"],
  Clientes:["telefono","nombre","fechaRegistro","ultimoPedido"],
  Usuarios:["usuario","passwordHash","rol","activo"],
  ZonasDelivery:["id","zona","tarifa","activa"],
  HistorialEstados:["pedidoId","fecha","estado","usuario"],
  Sesiones:["token","usuario","expira"]
};
function doGet(){return ContentService.createTextOutput("Matibatidos Online API activa").setMimeType(ContentService.MimeType.TEXT);}
function doPost(e){
  try{
    const p=JSON.parse(e.postData.contents||"{}");
    const result=route_(p);
    return json_({ok:true,...result});
  }catch(err){return json_({ok:false,error:String(err.message||err)});}
}
function json_(o){return ContentService.createTextOutput(JSON.stringify(o)).setMimeType(ContentService.MimeType.JSON);}
function route_(p){
  switch(p.action){
    case "ping":return {message:"API Matibatidos Online conectada."};
    case "listMenu":return listMenu_();
    case "createOrder":return createOrder_(p.pedido||{});
    case "lookupOrders":return lookupOrders_(p.telefono);
    case "login":return login_(p);
    case "adminOrders":auth_(p.token);return adminOrders_();
    case "adminProducts":auth_(p.token);return adminProducts_();
    case "saveProduct":auth_(p.token);return saveProduct_(p.producto||{});
    case "toggleProduct":auth_(p.token);return toggleProduct_(p.id);
    case "updateOrderStatus":auth_(p.token);return updateOrderStatus_(p);
    default:throw new Error("Acción no reconocida.");
  }
}
function ss_(){const id=PropertiesService.getScriptProperties().getProperty("SPREADSHEET_ID");if(!id)throw new Error("Ejecutá setupMatibatidos() y configurá la hoja de cálculo.");return SpreadsheetApp.openById(id);}
function rows_(name){const s=ss_().getSheetByName(name);const v=s.getDataRange().getValues();return v.slice(1).filter(r=>r.some(x=>x!=="")).map(r=>Object.fromEntries(SHEETS[name].map((h,i)=>[h,r[i]])));}
function append_(name,obj){const s=ss_().getSheetByName(name);s.appendRow(SHEETS[name].map(k=>obj[k]===undefined?"":obj[k]));}
function listMenu_(){return {products:rows_("Productos").filter(p=>String(p.activo).toLowerCase()!=="false"&&p.activo!==0),categories:rows_("Categorias").filter(c=>String(c.activo).toLowerCase()!=="false").sort((a,b)=>Number(a.orden)-Number(b.orden))};}
function createOrder_(o){
  if(!o.cliente||!o.telefono||!Array.isArray(o.items)||!o.items.length)throw new Error("Faltan datos del pedido.");
  if(o.tipoEntrega==="Delivery"&&!o.direccion)throw new Error("Falta la dirección de entrega.");
  const catalog=rows_("Productos"),detail=[];let total=0;
  o.items.forEach(i=>{const p=catalog.find(x=>String(x.id)===String(i.id)&&String(x.activo).toLowerCase()!=="false");if(!p)throw new Error("Un producto ya no está disponible: "+i.nombre);const qty=Math.max(1,Math.min(50,Number(i.cantidad)||1));const price=Number(p.precio);const sub=price*qty;total+=sub;detail.push({pedidoId:"",productoId:p.id,nombre:p.nombre,cantidad:qty,precio:price,leche:i.leche||"",azucar:i.azucar||"",nota:i.nota||"",subtotal:sub});});
  const id=Utilities.getUuid(),code="MAT-"+Utilities.formatDate(new Date(),Session.getScriptTimeZone(),"yyMMdd")+"-"+id.slice(0,5).toUpperCase();
  const order={id,codigo:code,fecha:new Date(),cliente:String(o.cliente).slice(0,100),telefono:String(o.telefono).slice(0,30),tipoEntrega:o.tipoEntrega==="Delivery"?"Delivery":"Recoger",direccion:String(o.direccion||"").slice(0,300),notas:String(o.notas||"").slice(0,500),detalle:detail.map(x=>x.nombre+" x"+x.cantidad+" ("+x.leche+", "+x.azucar+")").join(" | "),total,estado:"Recibido"};
  append_("Pedidos",order);detail.forEach(d=>{d.pedidoId=id;append_("DetallePedidos",d);});
  const clients=rows_("Clientes");const existing=clients.find(c=>String(c.telefono)===order.telefono);
  if(!existing)append_("Clientes",{telefono:order.telefono,nombre:order.cliente,fechaRegistro:new Date(),ultimoPedido:new Date()});
  append_("HistorialEstados",{pedidoId:id,fecha:new Date(),estado:"Recibido",usuario:"Cliente"});
  return {codigo:code,total};
}
function lookupOrders_(phone){const key=String(phone||"").replace(/\s/g,"");if(!key)throw new Error("Ingresá tu teléfono.");return {orders:rows_("Pedidos").filter(o=>String(o.telefono).replace(/\s/g,"")===key).sort((a,b)=>new Date(b.fecha)-new Date(a.fecha)).slice(0,20)};}
function login_(p){const u=rows_("Usuarios").find(x=>x.usuario===p.usuario&&String(x.activo).toLowerCase()!=="false");if(!u||u.passwordHash!==hash_(String(p.contrasena||"")))throw new Error("Usuario o contraseña incorrectos.");const token=Utilities.getUuid()+Utilities.getUuid();append_("Sesiones",{token,usuario:u.usuario,expira:new Date(Date.now()+8*60*60*1000)});return {token,rol:u.rol};}
function auth_(token){const s=rows_("Sesiones").find(x=>x.token===token&&new Date(x.expira)>new Date());if(!s)throw new Error("Sesión vencida. Iniciá sesión nuevamente.");return s;}
function adminOrders_(){return {orders:rows_("Pedidos").sort((a,b)=>new Date(b.fecha)-new Date(a.fecha)).slice(0,100)};}
function adminProducts_(){return {products:rows_("Productos")};}
function saveProduct_(p){if(!p.nombre||!Number.isFinite(Number(p.precio))||Number(p.precio)<0)throw new Error("Nombre y precio válido son obligatorios.");const id=Utilities.getUuid();append_("Productos",{id,nombre:String(p.nombre).slice(0,100),categoria:String(p.categoria||"Otros"),descripcion:String(p.descripcion||""),precio:Number(p.precio),imagen:String(p.imagen||""),activo:p.activo===false?false:true,permiteLeche:p.permiteLeche===true});return {id};}
function toggleProduct_(id){const s=ss_().getSheetByName("Productos"),v=s.getDataRange().getValues();for(let i=1;i<v.length;i++){if(String(v[i][0])===String(id)){s.getRange(i+1,7).setValue(String(v[i][6]).toLowerCase()==="true"||v[i][6]===1?false:true);return {updated:true};}}throw new Error("Producto no encontrado.");}
function updateOrderStatus_(p){const s=ss_().getSheetByName("Pedidos"),v=s.getDataRange().getValues();for(let i=1;i<v.length;i++){if(String(v[i][0])===String(p.id)){s.getRange(i+1,11).setValue(String(p.estado));append_("HistorialEstados",{pedidoId:p.id,fecha:new Date(),estado:String(p.estado),usuario:"Administrador"});return {updated:true};}}throw new Error("Pedido no encontrado.");}
function hash_(s){return Utilities.computeDigest(Utilities.DigestAlgorithm.SHA_256,s,Utilities.Charset.UTF_8).map(b=>(b+256).toString(16).slice(-2)).join("");}
function setupMatibatidos(){
  const ss=SpreadsheetApp.getActiveSpreadsheet();if(!ss)throw new Error("Abrí el proyecto desde Extensiones > Apps Script dentro de la hoja de cálculo.");
  PropertiesService.getScriptProperties().setProperty("SPREADSHEET_ID",ss.getId());
  Object.keys(SHEETS).forEach(name=>{let sh=ss.getSheetByName(name)||ss.insertSheet(name);if(sh.getLastRow()===0)sh.appendRow(SHEETS[name]);sh.setFrozenRows(1);});
  const users=ss.getSheetByName("Usuarios");if(users.getLastRow()<2)users.appendRow(["admin",hash_("Cambiar123!"),"admin",true]);
  const config=ss.getSheetByName("Configuracion");if(config.getLastRow()<2){config.appendRow(["nombreNegocio","Matibatidos"]);config.appendRow(["moneda","NIO"]);config.appendRow(["telefonoWhatsApp","+50586429493"]);}
  SpreadsheetApp.getUi().alert("Estructura creada. Usuario inicial: admin. Contraseña temporal: Cambiar123! Cambiala antes de compartir la APK.");
}
