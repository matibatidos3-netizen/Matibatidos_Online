# Matibatidos Online — proyecto inicial integrado

Una sola APK Android para clientes y administración. El cliente instala la misma APK y entra al modo cliente; el personal usa el acceso administrativo protegido. El proyecto usa una interfaz HTML local dentro de Android WebView y Google Apps Script + Google Sheets como backend.

## Contenido
- `app/`: APK Android, interfaz cliente y administración.
- `backend/Code.gs`: API de Google Apps Script.
- `.github/workflows/build-apk.yml`: compilación automática en GitHub Actions.
- 10 hojas de datos creadas por `setupMatibatidos()`.

## 1. Crear la base de datos
1. Creá una hoja nueva en Google Sheets para Matibatidos Online.
2. Abrí **Extensiones > Apps Script**.
3. Copiá el contenido de `backend/Code.gs` en `Code.gs`.
4. Guardá y ejecutá `setupMatibatidos()` desde Apps Script.
5. Aceptá los permisos solicitados.
6. La función crea las hojas: Configuracion, Productos, Categorias, Pedidos, DetallePedidos, Clientes, Usuarios, ZonasDelivery, HistorialEstados y Sesiones.
7. En `Usuarios` se crea temporalmente `admin` / `Cambiar123!`. Cambiá esta contraseña antes de compartir la aplicación.

## 2. Publicar el backend
1. En Apps Script: **Implementar > Nueva implementación > Aplicación web**.
2. Ejecutar como: **tu cuenta**.
3. Quién tiene acceso: **Cualquier persona** (la API necesita recibir pedidos de clientes sin iniciar sesión).
4. Implementá y copiá la URL terminada en `/exec`.
5. Abrí Matibatidos Online en Android, tocá ⚙, pegá la URL y guardá.

**Seguridad:** el acceso administrativo exige usuario y contraseña, pero el endpoint público permite crear pedidos y consultar pedidos por teléfono. No compartás la hoja de cálculo ni la contraseña temporal. Antes de producción se recomienda agregar limitación de intentos, verificación antiabuso y un proceso de cambio de contraseña dentro de la APK.

## 3. Compilar la APK en GitHub
1. Creá un repositorio nuevo en GitHub.
2. Subí el contenido de este ZIP conservando las carpetas.
3. Abrí **Actions > Construir APK Matibatidos Online > Run workflow**.
4. Al finalizar, descargá el artefacto `Matibatidos-Online-APK`.
5. Dentro encontrarás `app-debug.apk`, instalable en Android.

## 4. Cargar productos
En Google Sheets, agregá filas en `Productos` con las columnas:
`id | nombre | categoria | descripcion | precio | imagen | activo | permiteLeche`

- `id`: identificador único (por ejemplo `BAT001`).
- `activo`: TRUE o FALSE.
- `permiteLeche`: TRUE o FALSE.
- `imagen`: URL HTTPS pública de una imagen.

Agregá categorías en `Categorias` (`id | nombre | orden | activo`).

## Alcance de esta primera entrega
Incluye menú, carrito, opciones de leche/azúcar/comentarios, pedidos para recoger o delivery, registro básico de clientes, consulta de pedidos por teléfono, login administrativo, listado/actualización de pedidos y alta/visibilidad de productos.

Todavía requiere completar antes de uso comercial: edición completa de productos, tarifas de delivery por zona (la hoja está creada pero no aplicada al cálculo), carga/optimización de fotografías, recuperación de cuenta, notificaciones push, validación antifraude, políticas de privacidad y pruebas de concurrencia. La confirmación de pedidos no genera factura ni modifica el POS existente: la facturación se hace manualmente en el POS actual, tal como se definió para mantenerlo independiente.

## Configuración de Android
- Application ID: `com.matibatidos.online`
- Nombre: `Matibatidos Online`
- Java 17, Android Gradle Plugin 8.7.3, Gradle 8.9
- Min SDK 23 (Android 6.0)
